package com.example.yogacourseactivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// EntriesAdapter.java
public class EntriesAdapter extends RecyclerView.Adapter<EntriesAdapter.EntryViewHolder> {
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public interface OnUpdateClickListener {
        void onUpdateClick(int position);
    }

    private List<YogaEntry> entries;
    private OnDeleteClickListener onDeleteClickListener;

    public EntriesAdapter(List<YogaEntry> entries, OnDeleteClickListener onDeleteClickListener, ViewEntriesActivity viewEntriesActivity) {
        this.entries = entries;
        this.onDeleteClickListener = onDeleteClickListener;
    }








    @NonNull
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entry, parent, false);
        return new EntryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder holder, int position) {
        holder.bind(entries.get(position));
    }


    @Override
    public int getItemCount() {
        return entries.size();
    }
    public List<YogaEntry> getEntries() {
        return entries;
    }

    class EntryViewHolder extends RecyclerView.ViewHolder {
        private TextView tvEntryDetails;
        private Button btnDeleteEntry;
        private Button btnUpdateEntry;

        EntryViewHolder(View itemView, OnDeleteClickListener onDeleteClickListener, OnUpdateClickListener onUpdateClickListener) {
            super(itemView);
            tvEntryDetails = itemView.findViewById(R.id.tvEntryDetails);
            btnDeleteEntry = itemView.findViewById(R.id.btnDeleteEntry);
            btnUpdateEntry = itemView.findViewById(R.id.btnUpdateEntry);

            btnDeleteEntry.setOnClickListener(view -> {
                if (onDeleteClickListener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        onDeleteClickListener.onDeleteClick(position);
                    }
                }
            });

            btnUpdateEntry.setOnClickListener(view -> {
                if (onUpdateClickListener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        onUpdateClickListener.onUpdateClick(position);
                    }
                }
            });
        }

        void bind(YogaEntry entry) {
            // Format the data and set it to the TextView
            String details = "Day: " + entry.getDayOfWeek() +
                    "\nTime: " + entry.getTime() +
                    "\nCapacity: " + entry.getCapacity() +
                    "\nDuration: " + entry.getDuration() +
                    "\nPrice: " + entry.getPrice() +
                    "\nType: " + entry.getType() +
                    "\nDescription: " + entry.getDescription();

            tvEntryDetails.setText(details);
        }
    }

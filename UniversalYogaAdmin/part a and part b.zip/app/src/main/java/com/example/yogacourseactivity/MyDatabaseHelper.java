package com.example.yogacourseactivity;

// MyDatabaseHelper.java
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    // Database name and version
    private static final String DATABASE_NAME = "yoga_db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names
    public static final String TABLE_YOGA_ENTRIES = "yoga_entries";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_DAY_OF_WEEK = "dayOfWeek";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_CAPACITY = "capacity";
    public static final String COLUMN_DURATION = "duration";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_DESCRIPTION = "description";

    // SQL query to create the table
    private static final String CREATE_TABLE_YOGA_ENTRIES = "CREATE TABLE " + TABLE_YOGA_ENTRIES + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_DAY_OF_WEEK + " TEXT, " +
            COLUMN_TIME + " TEXT, " +
            COLUMN_CAPACITY + " INTEGER, " +
            COLUMN_DURATION + " TEXT, " +
            COLUMN_PRICE + " TEXT, " +
            COLUMN_TYPE + " TEXT, " +
            COLUMN_DESCRIPTION + " TEXT)";

    public MyDatabaseHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        db.execSQL(CREATE_TABLE_YOGA_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades, if needed
        // Typically involves modifying the table schema or data migration
        // Here, you can drop the old table and create a new one
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_YOGA_ENTRIES);
        onCreate(db);
    }

    public Long insertYogaEntry(YogaEntry entry) {
        return null;
    }
}


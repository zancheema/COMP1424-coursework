package com.example.yogacourseactivity;
import android.app.Application;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
        import androidx.lifecycle.AndroidViewModel;
        import androidx.lifecycle.LiveData;
        import androidx.lifecycle.MutableLiveData;

public class YogaEntryViewModel extends AndroidViewModel {
    private final MutableLiveData<Long> insertionResult = new MutableLiveData<>();
    private final MyDatabaseHelper dbHelper;

    public YogaEntryViewModel(@NonNull Application application) {
        super(application);
        dbHelper = new MyDatabaseHelper(application);
    }

    public LiveData<Long> getInsertionResult() {
        return insertionResult;
    }

    public void insertYogaEntry(YogaEntry entry) {
        new InsertAsyncTask().execute(entry);
    }

    private class InsertAsyncTask extends AsyncTask<YogaEntry, Void, Long> {
        @Override
        protected Long doInBackground(YogaEntry... entries) {
            YogaEntry entry = entries[0];
            return dbHelper.insertYogaEntry(entry);
        }

        @Override
        protected void onPostExecute(Long newRowId) {
            insertionResult.setValue(newRowId);
        }
    }
}


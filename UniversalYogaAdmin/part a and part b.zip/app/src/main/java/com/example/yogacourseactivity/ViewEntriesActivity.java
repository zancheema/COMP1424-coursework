package com.example.yogacourseactivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

// ViewEntriesActivity.java
public class ViewEntriesActivity extends AppCompatActivity implements EntriesAdapter.OnDeleteClickListener, EntriesAdapter.OnUpdateClickListener {
    private MyDatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private EntriesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_entries);

        dbHelper = new MyDatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewEntries);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve data and set up the adapter
        List<YogaEntry> entries = retrieveEntryData();

        // Initialize the adapter with the onDeleteClickListener
        adapter = new EntriesAdapter(entries, this, this, onUpdateClickListener:this);
        recyclerView.setAdapter(adapter);
    }


    public void onDeleteClick(int position) {
        // Handle deletion here
        YogaEntry entryToDelete = adapter.getEntries().get(position);;

        // Call a method to delete the entry from the database
        deleteEntryFromDatabase(entryToDelete.getId());

        // Remove the entry from the list and update the adapter
        adapter.getEntries().remove(position);
        adapter.notifyItemRemoved(position);
    }

    @Override
    public void onUpdateClick(int position) {
        // Handle update click here
        YogaEntry entryToUpdate = adapter.getEntries().get(position);

        // You can start a new activity for updating details or show a dialog, etc.
        // For example, start UpdateEntryActivity and pass the entry details
        Intent intent = new Intent(ViewEntriesActivity.this, UpdateEntryActivity.class);
        intent.putExtra("entryToUpdate", entryToUpdate);
        startActivity(intent);
    }


    private void deleteEntryFromDatabase(long entryId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(MyDatabaseHelper.TABLE_YOGA_ENTRIES, MyDatabaseHelper.COLUMN_ID + "=?",
                new String[]{String.valueOf(entryId)});
        db.close();
    }

    private List<YogaEntry> retrieveEntryData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Perform a query to retrieve the data

        Cursor cursor = db.rawQuery("SELECT * FROM yoga_entries", null);

        List<YogaEntry> entries = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                // Retrieve data from the cursor and create a YogaEntry object
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String dayOfWeek = cursor.getString(cursor.getColumnIndexOrThrow("dayOfWeek"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                int capacity = cursor.getInt(cursor.getColumnIndexOrThrow("capacity"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration"));
                String price = cursor.getString(cursor.getColumnIndexOrThrow("price"));
                String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                YogaEntry entry = new YogaEntry(id, dayOfWeek, time, capacity, duration, price, type, description);
                entries.add(entry);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return entries;
    }
}


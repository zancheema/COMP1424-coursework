package com.example.yogacourseactivity;

public class IntentKeys {
    public static final String DAY_OF_WEEK = "DAY_OF_WEEK";
    public static final String TIME = "TIME";
    public static final String CAPACITY = "CAPACITY";
    public static final String DURATION = "DURATION";
    public static final String PRICE = "PRICE";
    public static final String TYPE = "TYPE";
    public static final String DESCRIPTION = "DESCRIPTION";
}
package com.example.yogacourseactivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        // Enable the Up button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Get the details from the Intent
        Intent intent = getIntent();
        String dayOfWeek = intent.getStringExtra(IntentKeys.DAY_OF_WEEK);
        String time = intent.getStringExtra(IntentKeys.TIME);
        int capacity = intent.getIntExtra(IntentKeys.CAPACITY, 0);
        String duration = intent.getStringExtra(IntentKeys.DURATION);
        String price = intent.getStringExtra(IntentKeys.PRICE);
        String type = intent.getStringExtra(IntentKeys.TYPE);
        String description = intent.getStringExtra(IntentKeys.DESCRIPTION);

        // Display the details in TextView
        TextView tvConfirmationDetails = findViewById(R.id.tvConfirmationDetails);
        String details = "Day: " + dayOfWeek + "\nTime: " + time + "\nCapacity: " + capacity +
                "\nDuration: " + duration + "\nPrice: " + price + "\nType: " + type +
                "\nDescription: " + description;
        tvConfirmationDetails.setText(details);
    }

    // This method is called when the "Edit Details" button is clicked
    public void onEditDetailsClick(View view) {
        // Handle the Up button click
        NavUtils.navigateUpFromSameTask(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // Handle the Up button click
                NavUtils.navigateUpFromSameTask(this);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

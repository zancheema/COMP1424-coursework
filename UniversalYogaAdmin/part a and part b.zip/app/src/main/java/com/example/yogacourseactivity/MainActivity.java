package com.example.yogacourseactivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class MainActivity extends AppCompatActivity {

    private EditText editDayOfWeek, editTime, editCapacity, editDuration, editPrice, editType, editDescription;
    private YogaEntryViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewModel = new ViewModelProvider(this).get(YogaEntryViewModel.class);

        // Initialize EditText fields
        editDayOfWeek = findViewById(R.id.editDayOfWeek);
        editTime = findViewById(R.id.editTime);
        editCapacity = findViewById(R.id.editCapacity);
        editDuration = findViewById(R.id.editDuration);
        editPrice = findViewById(R.id.editPrice);
        editType = findViewById(R.id.editType);
        editDescription = findViewById(R.id.editDescription);

        viewModel.getInsertionResult().observe(this, newRowId -> {
            if (newRowId != -1) {
                // Insertion successful, start ConfirmationActivity
                // Adjust as needed based on your Intent handling
                Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
            } else {
                // Handle the case where insertion failed
                Toast.makeText(this, "Failed to insert data into the database", Toast.LENGTH_SHORT).show();
            }
        });
    }



    public void onSubmitClick(View view) {
        // Get input values
        String dayOfWeek = editDayOfWeek.getText().toString().trim();
        String time = editTime.getText().toString().trim();
        String capacity = editCapacity.getText().toString().trim();
        String duration = editDuration.getText().toString().trim();
        String price = editPrice.getText().toString().trim();
        String type = editType.getText().toString().trim();
        String description = editDescription.getText().toString().trim();

        // Check for required fields
        if (dayOfWeek.isEmpty() || time.isEmpty() || capacity.isEmpty() || duration.isEmpty() || price.isEmpty() || type.isEmpty()) {
            // Display an error message
            Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int capacityValue = Integer.parseInt(capacity);
            YogaEntry entry = new YogaEntry(0, dayOfWeek, time, capacityValue, duration, price, type, description);

            viewModel.insertYogaEntry(entry);

            MyDatabaseHelper dbHelper = new MyDatabaseHelper(this); //stores input into database
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(MyDatabaseHelper.COLUMN_DAY_OF_WEEK, dayOfWeek);
            values.put(MyDatabaseHelper.COLUMN_TIME, time);
            values.put(MyDatabaseHelper.COLUMN_CAPACITY, capacityValue);
            values.put(MyDatabaseHelper.COLUMN_DURATION, duration);
            values.put(MyDatabaseHelper.COLUMN_PRICE, price);
            values.put(MyDatabaseHelper.COLUMN_TYPE, type);
            values.put(MyDatabaseHelper.COLUMN_DESCRIPTION, description);

            long newRowId = db.insert(MyDatabaseHelper.TABLE_YOGA_ENTRIES, null, values);

            db.close();
            // Assuming you want to start ConfirmationActivity after successful submission

            if (newRowId != -1) {
                Intent intent = new Intent(MainActivity.this, ConfirmationActivity.class);
                intent.putExtra(IntentKeys.DAY_OF_WEEK, dayOfWeek);
                intent.putExtra(IntentKeys.TIME, time);
                intent.putExtra(IntentKeys.CAPACITY, capacityValue);
                intent.putExtra(IntentKeys.DURATION, duration);
                intent.putExtra(IntentKeys.PRICE, price);
                intent.putExtra(IntentKeys.TYPE, type);
                intent.putExtra(IntentKeys.DESCRIPTION, description);

                startActivity(intent);

            } else {
                // Handle the case where insertion failed
                Toast.makeText(this, "Failed to insert data into the database", Toast.LENGTH_SHORT).show();
            }
        }
            catch (NumberFormatException e) {
            // Handle the case where capacity is not a valid integer
            Toast.makeText(this, "Capacity should be a valid number", Toast.LENGTH_SHORT).show();
        }
    }
        public void onViewEntriesClick(View view) {
            Intent intent = new Intent(MainActivity.this, ViewEntriesActivity.class);
            startActivity(intent);
        }
    }


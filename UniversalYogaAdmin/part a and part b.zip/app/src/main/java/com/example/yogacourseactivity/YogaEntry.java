package com.example.yogacourseactivity;

public class YogaEntry {
    // YogaEntry.java

        private long id;  // Assuming an ID for database operations
        private String dayOfWeek;
        private String time;
        private int capacity;
        private String duration;
        private String price;
        private String type;
        private String description;

        public YogaEntry(long id, String dayOfWeek, String time, int capacity, String duration, String price, String type, String description) {
            this.id = id;
            this.dayOfWeek = dayOfWeek;
            this.time = time;
            this.capacity = capacity;
            this.duration = duration;
            this.price = price;
            this.type = type;
            this.description = description;
        }

        // Getters and setters for each field
        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getDayOfWeek() {
            return dayOfWeek;
        }

        public void setDayOfWeek(String dayOfWeek) {
            this.dayOfWeek = dayOfWeek;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public int getCapacity() {
            return capacity;
        }

        public void setCapacity(int capacity) {
            this.capacity = capacity;
        }

        public String getDuration() {
            return duration;
        }

        public void setDuration(String duration) {
            this.duration = duration;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }
    }



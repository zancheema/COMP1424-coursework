export const dummyClasses = [ 
    {
        "instanceId": 1, 
        "date": "24/10/2023", 
        "teacher": "Russell", 
        "classDay": "Tuesday",
        "classTime":"18:00"
    },
    {
        "instanceId": 2, 
        "date": "31/10/2023", 
        "teacher": "Joe",
        "classDay": "Tuesday",
        "classTime": "18:00"
    },
    {
        "instanceId":3,
        "date": "26/10/2023", 
        "teacher":"Elena", 
        "classDay": "Thursday",
        "classTime":"07:00"
    },
    {
        "instanceId":4,
        "date": "02/11/2023", 
        "teacher": "Katya", 
        "classDay": "Thursday",
        "classTime":"07:00"
    },
    {
        "instanceId":5,
        "date": "24/10/2023", 
        "teacher": "Russell", 
        "classDay": "Tuesday",
        "classTime":"18:00"
    }, 
    {
        "instanceId":6,
        "date": "31/10/2023", 
        "teacher": "Joe",
        "classDay": "Tuesday",
        "classTime": "18:00"
    },
    {
        "instanceId":7,
        "date": "26/10/2023", 
        "teacher":"Elena", 
        "classDay": "Thursday",
        "classTime":"07:00"
    },
    {
        "instanceId":8,
        "date": "02/11/2023", 
        "teacher": "Katya",
        "classDay": "Thursday", 
        "classTime":"07:00"
    }
];
